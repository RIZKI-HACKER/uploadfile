# DarkFB Termux

<ul>
<li><code>pkg install git python2</code></li>
<li><code>pip2 install --upgrade pip</code></li>
<li><code>git clone https://github.com/TheMagizz/DarkPremium</code></li>
<li><code>cd DarkPremium</code></li>
<li><code>pip2 install -r requirements.txt</code></li>
<li><code>python2 DarkFB.py</code></li>
</ul>
<br />
<br />
<img src="https://github.com/TheMagizz/DarkPremium/blob/master/Screenshot_2019-07-03-22-49-47-917_com.termux.png" />
